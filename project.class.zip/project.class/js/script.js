 let mobileMenu = document.querySelector('.mobile-menu')

document.querySelector('#moblie').onclick = () =>{
    mobileMenu.classList.toggle('active')
}  
 
 
